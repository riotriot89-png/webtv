import os
import discord
from discord import app_commands
import httpx
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_BOT_TOKEN")
GUILD_ID = int(os.getenv("GUILD_ID"))
BOT_SECRET = os.getenv("BOT_SECRET")
API_BASE = os.getenv("API_BASE_URL")

HEADERS = {"x-bot-secret": BOT_SECRET, "Content-Type": "application/json"}

# ── Setup ────────────────────────────────────────────────────────────────────
intents = discord.Intents.default()
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)
guild_obj = discord.Object(id=GUILD_ID)


async def api(method: str, path: str, body: dict = None):
    async with httpx.AsyncClient() as c:
        r = await c.request(method, f"{API_BASE}{path}", json=body, headers=HEADERS)
        return r.json()


# ── /addmember ───────────────────────────────────────────────────────────────
@tree.command(guild=guild_obj, name="addmember", description="Thêm thành viên vào bảng vinh danh")
@app_commands.describe(user="Chọn thành viên")
async def addmember(interaction: discord.Interaction, user: discord.Member):
    await interaction.response.defer(ephemeral=True)
    result = await api("POST", "/api/members?action=add", {"discord_id": str(user.id)})
    if "error" in result:
        return await interaction.followup.send(f"❌ {result['error']}")
    m = result["member"]
    embed = discord.Embed(title="✅ Đã thêm thành viên!", color=0xC9A84C)
    embed.description = f"**{m['name']}** → vị trí **#{m['position']}**"
    if m.get("avatar_url"):
        embed.set_thumbnail(url=m["avatar_url"])
    await interaction.followup.send(embed=embed)


# ── /removemember ────────────────────────────────────────────────────────────
@tree.command(guild=guild_obj, name="removemember", description="Xóa thành viên khỏi bảng vinh danh")
@app_commands.describe(user="Chọn thành viên")
async def removemember(interaction: discord.Interaction, user: discord.Member):
    await interaction.response.defer(ephemeral=True)
    result = await api("DELETE", "/api/members?action=remove", {"discord_id": str(user.id)})
    if "error" in result:
        return await interaction.followup.send(f"❌ {result['error']}")
    await interaction.followup.send(f"✅ Đã xóa **{user.display_name}**. Còn lại **{result['remaining']}** người.")


# ── /listmembers ─────────────────────────────────────────────────────────────
@tree.command(guild=guild_obj, name="listmembers", description="Xem danh sách thành viên hiện tại")
async def listmembers(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    result = await api("GET", "/api/members")
    members = result.get("members", [])
    if not members:
        return await interaction.followup.send("📭 Danh sách đang trống.")
    lines = [f"**#{m['position']}** — {m['name']} `({m['discord_id']})`" for m in members]
    embed = discord.Embed(title=f"🐱 Bảng Vinh Danh ({len(members)} người)", color=0xC9A84C)
    embed.description = "\n".join(lines)
    embed.set_footer(text="Dùng /movemember để đổi thứ tự")
    await interaction.followup.send(embed=embed)


# ── /movemember ──────────────────────────────────────────────────────────────
@tree.command(guild=guild_obj, name="movemember", description="Đổi vị trí thành viên")
@app_commands.describe(user="Chọn thành viên", position="Vị trí mới (bắt đầu từ 1)")
async def movemember(interaction: discord.Interaction, user: discord.Member, position: int):
    await interaction.response.defer(ephemeral=True)
    result = await api("GET", "/api/members")
    members = result.get("members", [])
    if not members:
        return await interaction.followup.send("❌ Danh sách trống.")

    target = next((m for m in members if m["discord_id"] == str(user.id)), None)
    if not target:
        return await interaction.followup.send(f"❌ **{user.display_name}** chưa có trong danh sách.")

    others = [m for m in members if m["discord_id"] != str(user.id)]
    insert_at = max(0, min(position - 1, len(others)))
    others.insert(insert_at, target)
    ordered_ids = [m["discord_id"] for m in others]

    result = await api("POST", "/api/members?action=reorder", {"ordered_ids": ordered_ids})
    if "error" in result:
        return await interaction.followup.send(f"❌ {result['error']}")
    await interaction.followup.send(f"✅ Đã chuyển **{target['name']}** lên vị trí **#{insert_at + 1}**.")


# ── Start ────────────────────────────────────────────────────────────────────
@client.event
async def on_ready():
    await tree.sync(guild=guild_obj)
    print(f"✅ Bot online: {client.user} | Commands synced to guild {GUILD_ID}")

client.run(TOKEN)
