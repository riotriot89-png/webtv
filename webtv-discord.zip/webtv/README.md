# 🐱 Ổ Mèo — Hướng dẫn Deploy

## Kiến trúc

```
Website (Vercel)
    ├── public/index.html       → Trang hiển thị thành viên (fetch API)
    ├── public/admin.html       → Trang quản lý (giữ nguyên)
    └── api/members.js          → API endpoint (Vercel Serverless)

Bot Discord (chạy local)
    └── bot.js                  → Slash commands quản lý danh sách
```

---

## Bước 1 — Tạo Vercel KV (database miễn phí)

1. Vào https://vercel.com → project của bạn → **Storage** → **Create Database**
2. Chọn **KV (Redis)** → đặt tên → **Create**
3. Sau khi tạo, vào tab **.env.local** → copy 4 dòng `KV_*` → paste vào file `.env`

---

## Bước 2 — Cấu hình Environment Variables trên Vercel

Vào **Project Settings → Environment Variables**, thêm:

| Key | Value |
|-----|-------|
| `DISCORD_BOT_TOKEN` | Token bot của bạn |
| `GUILD_ID` | ID server Discord |
| `BOT_SECRET` | Chuỗi bí mật tự đặt (ví dụ: `omeo_2026_secret`) |
| `KV_URL` | (tự điền khi tạo KV) |
| `KV_REST_API_URL` | (tự điền khi tạo KV) |
| `KV_REST_API_TOKEN` | (tự điền khi tạo KV) |
| `KV_REST_API_READ_ONLY_TOKEN` | (tự điền khi tạo KV) |

---

## Bước 3 — Deploy lên Vercel

### Cách A: Dùng Vercel CLI
```bash
npm i -g vercel
vercel login
vercel --prod
```

### Cách B: Kéo thả qua GitHub
1. Push code lên GitHub repo
2. Vào https://vercel.com → **New Project** → chọn repo
3. Vercel tự detect và deploy

---

## Bước 4 — Cấu hình Bot và chạy local

### Tạo file .env
```bash
cp .env.example .env
# Điền tất cả các giá trị vào .env
```

### Lấy DISCORD_CLIENT_ID
Vào https://discord.com/developers/applications → chọn bot → **General Information** → copy **Application ID**

### Lấy GUILD_ID
Trong Discord: chuột phải vào tên server → **Copy Server ID**
(Cần bật Developer Mode: Settings → Advanced → Developer Mode)

### Cài dependencies và chạy bot
```bash
npm install
node bot.js
```

---

## Bước 5 — Cấp quyền Bot vào Server

Vào Discord Developer Portal → OAuth2 → URL Generator:
- Scopes: `bot`, `applications.commands`
- Bot Permissions: `Read Messages`, `Send Messages`, `Use Slash Commands`

Mở URL được tạo → thêm bot vào server.

---

## Dùng bot như thế nào

| Lệnh | Tác dụng |
|------|----------|
| `/addmember @user` | Thêm thành viên (tự lấy tên + ảnh từ Discord) |
| `/removemember @user` | Xóa thành viên khỏi bảng |
| `/listmembers` | Xem danh sách + số thứ tự hiện tại |
| `/movemember @user 2` | Chuyển user về vị trí số 2 |

> Tất cả lệnh chỉ hiện với mình bạn (ephemeral), người khác không thấy.

---

## Lưu ý

- **Bot cần chạy local** (hoặc trên server riêng như Railway/Fly.io) để nhận lệnh slash.
  Vercel **không** phù hợp để host bot Discord liên tục (serverless = không giữ kết nối).
- Vercel chỉ host **website + API**. Bot chạy riêng.
- Vercel KV free tier: 30MB storage, 30.000 requests/ngày — hoàn toàn đủ dùng.
